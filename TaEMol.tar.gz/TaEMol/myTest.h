#ifndef MYTEST_H
#define MYTEST_H

#include <stdlib.h>
#include "./myGLUT.h"

#define WIN_WIDTH  (400)
#define WIN_HEIGHT (400)
#define WIN_POSX   (100)
#define WIN_POSY   (100)
#define WIN_NAME   "myTest"

#endif /* MYTEST_H */
